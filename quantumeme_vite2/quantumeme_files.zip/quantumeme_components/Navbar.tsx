import React, { useState } from 'react';
import { motion } from 'framer-motion';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  return (
    <nav className="fixed w-full z-50 bg-quantum-dark/80 backdrop-blur-md border-b border-quantum-primary/20">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center py-4">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            className="flex items-center"
          >
            <img 
              src="/src/assets/quantumeme_logo.png" 
              alt="QUANTUMEME Logo" 
              className="h-10 w-10 mr-2"
            />
            <span className="text-2xl font-quantum font-bold quantum-text">QUANTUMEME</span>
          </motion.div>

          {/* Desktop Menu */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="hidden md:flex items-center space-x-8"
          >
            <a href="#home" className="text-quantum-light hover:quantum-text transition-colors">Home</a>
            <a href="#about" className="text-quantum-light hover:quantum-text transition-colors">O que é?</a>
            <a href="#tokenomics" className="text-quantum-light hover:quantum-text transition-colors">Tokenomics</a>
            <a href="#roadmap" className="text-quantum-light hover:quantum-text transition-colors">Roadmap</a>
            <a href="#buy" className="text-quantum-light hover:quantum-text transition-colors">Como Comprar</a>
            <a href="#community" className="text-quantum-light hover:quantum-text transition-colors">Comunidade</a>
            <a href="#faq" className="text-quantum-light hover:quantum-text transition-colors">FAQ</a>
          </motion.div>

          <motion.button
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="hidden md:block quantum-gradient px-6 py-2 rounded-full text-white font-medium hover:opacity-90 transition-opacity"
          >
            Comprar $QTMM
          </motion.button>

          {/* Mobile Menu Button */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="md:hidden"
          >
            <button
              onClick={toggleMenu}
              className="text-quantum-light focus:outline-none"
            >
              {isOpen ? (
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              ) : (
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                </svg>
              )}
            </button>
          </motion.div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          transition={{ duration: 0.3 }}
          className="md:hidden bg-quantum-dark/95 backdrop-blur-md border-b border-quantum-primary/20"
        >
          <div className="container mx-auto px-4 py-4 flex flex-col space-y-4">
            <a href="#home" className="text-quantum-light hover:quantum-text transition-colors py-2" onClick={toggleMenu}>Home</a>
            <a href="#about" className="text-quantum-light hover:quantum-text transition-colors py-2" onClick={toggleMenu}>O que é?</a>
            <a href="#tokenomics" className="text-quantum-light hover:quantum-text transition-colors py-2" onClick={toggleMenu}>Tokenomics</a>
            <a href="#roadmap" className="text-quantum-light hover:quantum-text transition-colors py-2" onClick={toggleMenu}>Roadmap</a>
            <a href="#buy" className="text-quantum-light hover:quantum-text transition-colors py-2" onClick={toggleMenu}>Como Comprar</a>
            <a href="#community" className="text-quantum-light hover:quantum-text transition-colors py-2" onClick={toggleMenu}>Comunidade</a>
            <a href="#faq" className="text-quantum-light hover:quantum-text transition-colors py-2" onClick={toggleMenu}>FAQ</a>
            <button className="quantum-gradient px-6 py-2 rounded-full text-white font-medium hover:opacity-90 transition-opacity w-full">
              Comprar $QTMM
            </button>
          </div>
        </motion.div>
      )}
    </nav>
  );
};

export default Navbar;
