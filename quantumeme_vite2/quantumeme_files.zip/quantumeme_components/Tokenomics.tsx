import React from 'react';
import { motion } from 'framer-motion';

const Tokenomics: React.FC = () => {
  const distributionData = [
    { name: "Desenvolvimento e Operações", percentage: 30, color: "bg-quantum-purple" },
    { name: "Recompensas da Comunidade", percentage: 25, color: "bg-quantum-blue" },
    { name: "Marketing e Parcerias", percentage: 20, color: "bg-quantum-secondary" },
    { name: "Pool de Staking", percentage: 15, color: "bg-quantum-teal" },
    { name: "Liquidez Inicial", percentage: 10, color: "bg-quantum-pink" }
  ];

  return (
    <section id="tokenomics" className="py-20 bg-quantum-dark relative overflow-hidden">
      <div className="absolute inset-0 z-0 opacity-10" style={{ 
        backgroundImage: `url('/src/assets/quantum_pattern.png')`,
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      }}></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-quantum font-bold mb-4">
            <span className="quantum-text">Tokenomics</span>
          </h2>
          <p className="text-quantum-light/70 max-w-2xl mx-auto">
            Economia de token projetada para crescimento sustentável e recompensas à comunidade
          </p>
          <div className="w-24 h-1 quantum-gradient mx-auto rounded-full mt-4"></div>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center mb-16">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h3 className="text-2xl font-quantum font-bold mb-6 quantum-text">Suprimento e Distribuição</h3>
            <div className="bg-quantum-dark/80 p-6 rounded-2xl border border-quantum-primary/20">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h4 className="text-xl font-quantum font-bold quantum-text">42 Bilhões</h4>
                  <p className="text-quantum-light/70">Suprimento Total de Tokens</p>
                </div>
                <div className="w-16 h-16 rounded-full quantum-gradient flex items-center justify-center">
                  <span className="text-2xl">🪙</span>
                </div>
              </div>
              
              <p className="text-quantum-light/80 mb-6">
                O suprimento total foi fixado em 42 bilhões de tokens, uma referência à "Resposta para a Vida, o Universo e Tudo Mais" do livro "O Guia do Mochileiro das Galáxias", alinhando-se ao tema quântico e científico do projeto.
              </p>
              
              <div className="space-y-4">
                {distributionData.map((item, index) => (
                  <div key={index}>
                    <div className="flex justify-between mb-1">
                      <span className="text-quantum-light/90">{item.name}</span>
                      <span className="text-quantum-light/90">{item.percentage}%</span>
                    </div>
                    <div className="w-full bg-quantum-dark/50 rounded-full h-2.5">
                      <motion.div 
                        className={`h-2.5 rounded-full ${item.color}`}
                        style={{ width: `${item.percentage}%` }}
                        initial={{ width: 0 }}
                        whileInView={{ width: `${item.percentage}%` }}
                        viewport={{ once: true }}
                        transition={{ duration: 1, delay: 0.1 * index }}
                      ></motion.div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <h3 className="text-2xl font-quantum font-bold mb-6 quantum-text">Mecanismos Econômicos</h3>
            
            <div className="space-y-6">
              <div className="bg-quantum-dark/80 p-6 rounded-2xl border border-quantum-primary/20">
                <div className="flex items-center mb-3">
                  <div className="w-10 h-10 rounded-full quantum-gradient flex items-center justify-center mr-3">
                    <span className="text-lg">🔥</span>
                  </div>
                  <h4 className="text-lg font-quantum font-bold quantum-text">Mecanismos de Queima</h4>
                </div>
                <p className="text-quantum-light/80">
                  Eventos trimestrais de queima baseados no volume de transações, com 1% das taxas automaticamente queimadas, criando escassez e potencialmente aumentando o valor ao longo do tempo.
                </p>
              </div>
              
              <div className="bg-quantum-dark/80 p-6 rounded-2xl border border-quantum-primary/20">
                <div className="flex items-center mb-3">
                  <div className="w-10 h-10 rounded-full quantum-gradient flex items-center justify-center mr-3">
                    <span className="text-lg">⚛️</span>
                  </div>
                  <h4 className="text-lg font-quantum font-bold quantum-text">Staking Quântico</h4>
                </div>
                <p className="text-quantum-light/80">
                  APY dinâmico entre 42% e 137%, determinado por um "fator de superposição" único. O usuário só descobre o APY exato quando finaliza seu staking, similar ao experimento de Schrödinger.
                </p>
              </div>
              
              <div className="bg-quantum-dark/80 p-6 rounded-2xl border border-quantum-primary/20">
                <div className="flex items-center mb-3">
                  <div className="w-10 h-10 rounded-full quantum-gradient flex items-center justify-center mr-3">
                    <span className="text-lg">🐋</span>
                  </div>
                  <h4 className="text-lg font-quantum font-bold quantum-text">Mecanismos Anti-Whale</h4>
                </div>
                <p className="text-quantum-light/80">
                  Limites de transação (0,5% do suprimento total) e de carteira (2% do suprimento total) para prevenir manipulação de mercado e concentração excessiva de tokens.
                </p>
              </div>
            </div>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="bg-quantum-dark/80 p-8 rounded-2xl border border-quantum-primary/20 max-w-4xl mx-auto text-center"
        >
          <h3 className="text-2xl font-quantum font-bold mb-4 quantum-text">Eventos de Colapso Quântico</h3>
          <p className="text-quantum-light/80 mb-6 max-w-2xl mx-auto">
            Eventos periódicos (a cada 30 dias) onde 5 "Observadores Quânticos" (embaixadores ativos) são selecionados aleatoriamente para receber tokens extras do pool de staking.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <div className="bg-quantum-dark/50 px-6 py-3 rounded-full text-quantum-light/90 font-medium">
              <span className="mr-2">📅</span> Mensal
            </div>
            <div className="bg-quantum-dark/50 px-6 py-3 rounded-full text-quantum-light/90 font-medium">
              <span className="mr-2">🎁</span> 1% do Pool de Staking
            </div>
            <div className="bg-quantum-dark/50 px-6 py-3 rounded-full text-quantum-light/90 font-medium">
              <span className="mr-2">👥</span> 5 Ganhadores
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Tokenomics;
