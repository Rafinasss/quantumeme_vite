import React from 'react';
import { motion } from 'framer-motion';

const About: React.FC = () => {
  return (
    <section id="about" className="py-20 bg-quantum-dark/50 relative overflow-hidden">
      <div className="absolute inset-0 z-0 opacity-10" style={{ 
        backgroundImage: `url('/src/assets/quantum_pattern.png')`,
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      }}></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-quantum font-bold mb-4">
            <span className="quantum-text">O que é QUANTUMEME?</span>
          </h2>
          <p className="text-quantum-light/70 max-w-2xl mx-auto">
            Uma revolução no universo das moedas meme, combinando diversão viral com tecnologia blockchain avançada
          </p>
          <div className="w-24 h-1 quantum-gradient mx-auto rounded-full mt-4"></div>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center mb-16">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h3 className="text-2xl font-quantum font-bold mb-6 quantum-text">O Conceito Quântico</h3>
            <p className="text-quantum-light/80 mb-4">
              Assim como no famoso experimento mental de Schrödinger, onde um gato está simultaneamente vivo e morto até ser observado, o QUANTUMEME existe em um estado de superposição:
            </p>
            <ul className="space-y-3">
              <li className="flex items-start">
                <div className="text-quantum-secondary mr-3">•</div>
                <p className="text-quantum-light/80">Por um lado, um meme divertido e viral que captura a essência da cultura de internet</p>
              </li>
              <li className="flex items-start">
                <div className="text-quantum-secondary mr-3">•</div>
                <p className="text-quantum-light/80">Por outro, uma tecnologia blockchain séria com utilidades reais e inovadoras</p>
              </li>
              <li className="flex items-start">
                <div className="text-quantum-secondary mr-3">•</div>
                <p className="text-quantum-light/80">Quando você interage com o QUANTUMEME, "colapsa" seu potencial em valor tangível</p>
              </li>
            </ul>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <div className="bg-quantum-dark/80 p-6 rounded-2xl border border-quantum-primary/20">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 rounded-full quantum-gradient flex items-center justify-center mr-4">
                  <span className="text-2xl">🐱</span>
                </div>
                <h4 className="text-xl font-quantum font-bold quantum-text">Conheça Schrödinger</h4>
              </div>
              <p className="text-quantum-light/80 mb-4">
                Nosso mascote é um gato cósmico que existe em superposição quântica, representando a dualidade do QUANTUMEME como meme divertido e tecnologia séria.
              </p>
              <p className="text-quantum-light/80">
                Com olhos que brilham com a energia do universo quântico, Schrödinger guia nossa comunidade através do multiverso das criptomoedas, sempre em busca de oportunidades e inovação.
              </p>
            </div>
            
            <motion.div 
              className="absolute -bottom-6 -right-6 w-24 h-24 blur-2xl bg-quantum-purple/50 rounded-full z-0"
              animate={{ 
                scale: [1, 1.5, 1],
                opacity: [0.5, 0.8, 0.5]
              }}
              transition={{ 
                repeat: Infinity, 
                duration: 5,
                ease: "easeInOut"
              }}
            ></motion.div>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-6"
        >
          <div className="bg-quantum-dark/80 p-6 rounded-2xl border border-quantum-primary/20">
            <div className="w-16 h-16 rounded-full quantum-gradient flex items-center justify-center mb-4">
              <span className="text-2xl">🚀</span>
            </div>
            <h4 className="text-xl font-quantum font-bold mb-3 quantum-text">Layer-2 Aprimorada por IA</h4>
            <p className="text-quantum-light/80">
              Nossa solução Layer-2 proprietária utiliza algoritmos de IA para otimizar transações, reduzir custos e aumentar a velocidade na rede Polygon.
            </p>
          </div>
          
          <div className="bg-quantum-dark/80 p-6 rounded-2xl border border-quantum-primary/20">
            <div className="w-16 h-16 rounded-full quantum-gradient flex items-center justify-center mb-4">
              <span className="text-2xl">⚛️</span>
            </div>
            <h4 className="text-xl font-quantum font-bold mb-3 quantum-text">Staking Quântico</h4>
            <p className="text-quantum-light/80">
              Mecanismo inovador de staking com APY dinâmico entre 42% e 137%, determinado por um "fator de superposição" único gerado no momento do staking.
            </p>
          </div>
          
          <div className="bg-quantum-dark/80 p-6 rounded-2xl border border-quantum-primary/20">
            <div className="w-16 h-16 rounded-full quantum-gradient flex items-center justify-center mb-4">
              <span className="text-2xl">🔭</span>
            </div>
            <h4 className="text-xl font-quantum font-bold mb-3 quantum-text">Observatório de Memes</h4>
            <p className="text-quantum-light/80">
              Plataforma exclusiva alimentada por IA que analisa tendências de memes e criptomoedas em tempo real, fornecendo insights valiosos para nossa comunidade.
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default About;
