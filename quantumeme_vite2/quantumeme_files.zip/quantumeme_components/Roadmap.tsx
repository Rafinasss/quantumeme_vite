import React from 'react';
import { motion } from 'framer-motion';

const Roadmap: React.FC = () => {
  const roadmapItems = [
    {
      phase: "Fase 1: Lançamento",
      period: "Q2 2025",
      items: [
        "Distribuição inicial conforme alocação definida",
        "Listagem em DEXs na Polygon",
        "Início do programa de staking quântico"
      ],
      icon: "🚀"
    },
    {
      phase: "Fase 2: Expansão",
      period: "Q3 2025",
      items: [
        "Primeiro evento de Colapso Quântico",
        "Implementação do Observatório de Memes com IA",
        "Listagem em exchanges centralizadas de médio porte"
      ],
      icon: "📈"
    },
    {
      phase: "Fase 3: Adoção",
      period: "Q4 2025",
      items: [
        "Primeira queima programada baseada em volume",
        "Lançamento do programa de Observadores Quânticos",
        "Expansão para outras blockchains via bridges"
      ],
      icon: "🌐"
    },
    {
      phase: "Fase 4: Maturidade",
      period: "Q1 2026",
      items: [
        "Implementação completa da governança comunitária",
        "Integração com principais plataformas DeFi",
        "Desenvolvimento de casos de uso adicionais"
      ],
      icon: "⚖️"
    }
  ];

  return (
    <section id="roadmap" className="py-20 bg-quantum-dark/50 relative overflow-hidden">
      <div className="absolute inset-0 z-0 opacity-10" style={{ 
        backgroundImage: `url('/src/assets/quantum_pattern.png')`,
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      }}></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-quantum font-bold mb-4">
            <span className="quantum-text">Roadmap</span>
          </h2>
          <p className="text-quantum-light/70 max-w-2xl mx-auto">
            Nossa jornada através do multiverso quântico das criptomoedas
          </p>
          <div className="w-24 h-1 quantum-gradient mx-auto rounded-full mt-4"></div>
        </motion.div>

        <div className="relative">
          {/* Vertical line for desktop */}
          <div className="hidden md:block absolute left-1/2 transform -translate-x-1/2 h-full w-1 bg-quantum-primary/20 z-0"></div>
          
          {roadmapItems.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              className="relative z-10 mb-12"
            >
              <div className={`flex flex-col md:flex-row items-center ${index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'}`}>
                {/* Timeline dot */}
                <div className="hidden md:flex absolute left-1/2 transform -translate-x-1/2 w-12 h-12 rounded-full quantum-gradient items-center justify-center z-20">
                  <span className="text-xl">{item.icon}</span>
                </div>
                
                {/* Content */}
                <div className={`md:w-1/2 ${index % 2 === 0 ? 'md:pr-16 md:text-right' : 'md:pl-16'}`}>
                  <div className="bg-quantum-dark/80 p-6 rounded-2xl border border-quantum-primary/20">
                    <div className="flex items-center mb-4 md:hidden">
                      <div className="w-12 h-12 rounded-full quantum-gradient flex items-center justify-center mr-4">
                        <span className="text-xl">{item.icon}</span>
                      </div>
                      <div>
                        <h3 className="text-xl font-quantum font-bold quantum-text">{item.phase}</h3>
                        <p className="text-quantum-light/60">{item.period}</p>
                      </div>
                    </div>
                    
                    <div className="hidden md:block">
                      <h3 className="text-xl font-quantum font-bold quantum-text">{item.phase}</h3>
                      <p className="text-quantum-light/60 mb-4">{item.period}</p>
                    </div>
                    
                    <ul className={`space-y-2 ${index % 2 === 0 ? 'md:text-right' : ''}`}>
                      {item.items.map((listItem, i) => (
                        <li key={i} className="flex items-start md:items-center">
                          <div className={`text-quantum-secondary mr-3 ${index % 2 === 0 ? 'md:hidden' : ''}`}>•</div>
                          <p className="text-quantum-light/80">{listItem}</p>
                          <div className={`text-quantum-secondary ml-3 ${index % 2 === 0 ? 'md:inline-block hidden' : 'hidden'}`}>•</div>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
                
                {/* Empty space for alignment */}
                <div className="hidden md:block md:w-1/2"></div>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="bg-quantum-dark/80 p-8 rounded-2xl border border-quantum-primary/20 max-w-4xl mx-auto text-center mt-12"
        >
          <h3 className="text-2xl font-quantum font-bold mb-4 quantum-text">Visão de Longo Prazo</h3>
          <p className="text-quantum-light/80 mb-6 max-w-2xl mx-auto">
            Nossa missão é estabelecer o QUANTUMEME como uma referência no mercado de moedas meme, combinando o poder viral dos memes com utilidade real e tecnologia avançada.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <div className="bg-quantum-dark/50 px-6 py-3 rounded-full text-quantum-light/90 font-medium">
              <span className="mr-2">🔬</span> Inovação Contínua
            </div>
            <div className="bg-quantum-dark/50 px-6 py-3 rounded-full text-quantum-light/90 font-medium">
              <span className="mr-2">🌍</span> Expansão Global
            </div>
            <div className="bg-quantum-dark/50 px-6 py-3 rounded-full text-quantum-light/90 font-medium">
              <span className="mr-2">🤝</span> Parcerias Estratégicas
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Roadmap;
