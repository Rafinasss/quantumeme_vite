import React from 'react';
import { motion } from 'framer-motion';

const Hero: React.FC = () => {
  return (
    <section id="home" className="pt-24 pb-20 bg-quantum-dark relative overflow-hidden">
      <div className="absolute inset-0 z-0 opacity-20" style={{ 
        backgroundImage: `url('/src/assets/quantum_pattern.png')`,
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      }}></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="flex flex-col lg:flex-row items-center justify-between">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="lg:w-1/2 mb-12 lg:mb-0"
          >
            <h1 className="text-5xl md:text-6xl lg:text-7xl font-quantum font-bold mb-6">
              <span className="quantum-text">QUANTUM</span>
              <span className="text-quantum-light">EME</span>
            </h1>
            <h2 className="text-2xl md:text-3xl text-quantum-light/80 mb-8 font-quantum">
              Simultaneamente <span className="quantum-text">Meme</span> e <span className="quantum-text">Futuro</span>
            </h2>
            <p className="text-quantum-light/70 text-lg mb-8 max-w-xl">
              Uma moeda meme revolucionária que existe em superposição quântica: 
              por um lado, um meme divertido; por outro, tecnologia blockchain avançada 
              com staking quântico e ferramentas alimentadas por IA.
            </p>
            <div className="flex flex-wrap gap-4">
              <motion.button 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="quantum-gradient px-8 py-3 rounded-full text-white font-medium hover:opacity-90 transition-opacity"
              >
                Comprar $QTMM
              </motion.button>
              <motion.button 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="border-2 border-quantum-secondary px-8 py-3 rounded-full text-quantum-secondary font-medium hover:bg-quantum-secondary/10 transition-colors"
              >
                Whitepaper
              </motion.button>
            </div>
            <div className="flex items-center mt-8 space-x-6">
              <div className="flex items-center">
                <div className="w-3 h-3 rounded-full bg-quantum-teal mr-2"></div>
                <span className="text-quantum-light/70">Polygon Network</span>
              </div>
              <div className="flex items-center">
                <div className="w-3 h-3 rounded-full bg-quantum-secondary mr-2"></div>
                <span className="text-quantum-light/70">Auditado</span>
              </div>
              <div className="flex items-center">
                <div className="w-3 h-3 rounded-full bg-quantum-blue mr-2"></div>
                <span className="text-quantum-light/70">Staking Quântico</span>
              </div>
            </div>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="lg:w-1/2 flex justify-center"
          >
            <div className="relative">
              <motion.img 
                src="/src/assets/schrodinger_mascot.png" 
                alt="Schrödinger - QUANTUMEME Mascot" 
                className="max-w-full h-auto z-10 relative"
                animate={{ 
                  y: [0, -15, 0],
                }}
                transition={{ 
                  repeat: Infinity, 
                  duration: 6,
                  ease: "easeInOut"
                }}
              />
              <motion.div 
                className="absolute inset-0 blur-3xl bg-quantum-purple/30 rounded-full z-0"
                animate={{ 
                  scale: [1, 1.2, 1],
                  opacity: [0.5, 0.8, 0.5]
                }}
                transition={{ 
                  repeat: Infinity, 
                  duration: 8,
                  ease: "easeInOut"
                }}
              ></motion.div>
            </div>
          </motion.div>
        </div>
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6 text-center"
        >
          <div className="bg-quantum-dark/80 p-6 rounded-2xl border border-quantum-primary/20">
            <h3 className="text-3xl font-quantum font-bold mb-2 quantum-text">42B</h3>
            <p className="text-quantum-light/70">Suprimento Total</p>
          </div>
          <div className="bg-quantum-dark/80 p-6 rounded-2xl border border-quantum-primary/20">
            <h3 className="text-3xl font-quantum font-bold mb-2 quantum-text">137%</h3>
            <p className="text-quantum-light/70">APY Máximo</p>
          </div>
          <div className="bg-quantum-dark/80 p-6 rounded-2xl border border-quantum-primary/20">
            <h3 className="text-3xl font-quantum font-bold mb-2 quantum-text">0.001$</h3>
            <p className="text-quantum-light/70">Taxa de Transação</p>
          </div>
          <div className="bg-quantum-dark/80 p-6 rounded-2xl border border-quantum-primary/20">
            <h3 className="text-3xl font-quantum font-bold mb-2 quantum-text">2-3s</h3>
            <p className="text-quantum-light/70">Confirmação</p>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Hero;
