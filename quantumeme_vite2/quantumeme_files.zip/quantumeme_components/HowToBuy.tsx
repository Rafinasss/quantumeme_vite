import React from 'react';
import { motion } from 'framer-motion';

const HowToBuy: React.FC = () => {
  const steps = [
    {
      title: "Configurar uma Carteira",
      description: "Baixe e configure uma carteira compatível com Polygon, como MetaMask ou Trust Wallet.",
      icon: "👛",
      details: [
        "Visite metamask.io ou trustwallet.com e instale a extensão ou aplicativo",
        "Crie uma nova carteira seguindo as instruções",
        "Guarde sua frase de recuperação em um local seguro",
        "Adicione a rede Polygon à sua carteira"
      ]
    },
    {
      title: "Adquirir MATIC",
      description: "Compre MATIC (token nativo da Polygon) em uma exchange ou diretamente na sua carteira.",
      icon: "💰",
      details: [
        "Compre MATIC em exchanges como Binance, Coinbase ou KuCoin",
        "Alternativamente, use serviços de compra direta na sua carteira",
        "Transfira o MATIC para sua carteira pessoal",
        "Certifique-se de usar a rede Polygon para transferências"
      ]
    },
    {
      title: "Conectar a uma DEX",
      description: "Acesse uma exchange descentralizada (DEX) na rede Polygon, como QuickSwap ou SushiSwap.",
      icon: "🔄",
      details: [
        "Visite quickswap.exchange ou app.sushi.com",
        "Conecte sua carteira clicando em 'Connect Wallet'",
        "Selecione sua carteira (MetaMask, Trust Wallet, etc.)",
        "Confirme a conexão na janela pop-up da carteira"
      ]
    },
    {
      title: "Trocar MATIC por QTMM",
      description: "Use a DEX para trocar seus tokens MATIC por tokens QUANTUMEME ($QTMM).",
      icon: "🪙",
      details: [
        "Na interface da DEX, selecione MATIC como token de origem",
        "Cole o endereço do contrato QUANTUMEME no campo de busca",
        "Defina a quantidade de MATIC que deseja trocar",
        "Clique em 'Swap' e confirme a transação na sua carteira"
      ]
    },
    {
      title: "Ativar Staking Quântico (Opcional)",
      description: "Participe do mecanismo de Staking Quântico para ganhar recompensas com APY dinâmico.",
      icon: "⚛️",
      details: [
        "Visite a seção de Staking no site oficial do QUANTUMEME",
        "Conecte sua carteira e aprove o contrato de staking",
        "Escolha a quantidade de tokens e o período de bloqueio",
        "Confirme a transação e aguarde o 'colapso' para descobrir seu APY"
      ]
    }
  ];

  return (
    <section id="buy" className="py-20 bg-quantum-dark relative overflow-hidden">
      <div className="absolute inset-0 z-0 opacity-10" style={{ 
        backgroundImage: `url('/src/assets/quantum_pattern.png')`,
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      }}></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-quantum font-bold mb-4">
            <span className="quantum-text">Como Comprar</span>
          </h2>
          <p className="text-quantum-light/70 max-w-2xl mx-auto">
            Siga estes passos simples para adquirir seus tokens QUANTUMEME
          </p>
          <div className="w-24 h-1 quantum-gradient mx-auto rounded-full mt-4"></div>
        </motion.div>

        <div className="max-w-4xl mx-auto">
          {steps.map((step, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: index * 0.1 }}
              className="mb-8 relative"
            >
              {/* Connecting line */}
              {index < steps.length - 1 && (
                <div className="absolute left-6 top-16 w-1 bg-quantum-primary/20 h-full -z-10"></div>
              )}
              
              <div className="flex">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 rounded-full quantum-gradient flex items-center justify-center">
                    <span className="text-xl">{step.icon}</span>
                  </div>
                </div>
                
                <div className="ml-6 w-full">
                  <div className="bg-quantum-dark/80 p-6 rounded-2xl border border-quantum-primary/20">
                    <h3 className="text-xl font-quantum font-bold mb-2 quantum-text">
                      Passo {index + 1}: {step.title}
                    </h3>
                    <p className="text-quantum-light/80 mb-4">{step.description}</p>
                    
                    <div className="bg-quantum-dark/50 p-4 rounded-xl">
                      <h4 className="text-quantum-light font-medium mb-2">Detalhes:</h4>
                      <ul className="space-y-2">
                        {step.details.map((detail, i) => (
                          <li key={i} className="flex items-start">
                            <div className="text-quantum-secondary mr-3">•</div>
                            <p className="text-quantum-light/70">{detail}</p>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="bg-quantum-dark/80 p-8 rounded-2xl border border-quantum-primary/20 max-w-4xl mx-auto text-center mt-12"
        >
          <h3 className="text-2xl font-quantum font-bold mb-4 quantum-text">Informações Importantes</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <div className="bg-quantum-dark/50 p-4 rounded-xl">
              <div className="w-12 h-12 rounded-full quantum-gradient flex items-center justify-center mx-auto mb-3">
                <span className="text-xl">📝</span>
              </div>
              <h4 className="text-lg font-quantum font-medium mb-2 quantum-text">Contrato</h4>
              <p className="text-quantum-light/70 break-all text-sm">0x42c0de137A1e9D8F17CbB0b21F0858E079219b37</p>
            </div>
            
            <div className="bg-quantum-dark/50 p-4 rounded-xl">
              <div className="w-12 h-12 rounded-full quantum-gradient flex items-center justify-center mx-auto mb-3">
                <span className="text-xl">🔒</span>
              </div>
              <h4 className="text-lg font-quantum font-medium mb-2 quantum-text">Segurança</h4>
              <p className="text-quantum-light/70">Contrato auditado e liquidez bloqueada por 12 meses</p>
            </div>
            
            <div className="bg-quantum-dark/50 p-4 rounded-xl">
              <div className="w-12 h-12 rounded-full quantum-gradient flex items-center justify-center mx-auto mb-3">
                <span className="text-xl">💸</span>
              </div>
              <h4 className="text-lg font-quantum font-medium mb-2 quantum-text">Taxas</h4>
              <p className="text-quantum-light/70">Taxa de transação de apenas 1%, com 0,5% para liquidez e 0,5% para desenvolvimento</p>
            </div>
          </div>
          
          <div className="flex flex-wrap justify-center gap-4">
            <button className="quantum-gradient px-8 py-3 rounded-full text-white font-medium hover:opacity-90 transition-opacity flex items-center">
              <span className="mr-2">🔗</span> Contrato Verificado
            </button>
            <button className="border-2 border-quantum-secondary px-8 py-3 rounded-full text-quantum-secondary font-medium hover:bg-quantum-secondary/10 transition-colors flex items-center">
              <span className="mr-2">🔍</span> Auditoria
            </button>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default HowToBuy;
